import React from 'react'
import styles from '../styles/home/About.module.css'

const About = () => {
  return (
    <>
      <div className='screen'>
        <div className={styles.aboutContainer}>
          <div className={styles.aboutImage}>
            <img src='/images/aboutImage4.jpg' alt='About Muhammad Afnan' />
          </div>
          <div className={styles.aboutContent}>
            <div className={styles.heading}>
              <h2>
                Who is{' '}
                <span className={styles.companyColor}>Muhammad Afnan</span>
              </h2>
            </div>
            <div className={styles.para}>
              <p>
                Every great project begins with a spark of curiosity and a
                refusal to settle for the ordinary. Muhammad Afnan is the
                embodiment of that spirit—someone who doesn’t just code, but
                reimagines what’s possible. From a young passion for technology
                to leading innovative digital solutions, Afnan’s journey is
                defined by a relentless pursuit of knowledge and a drive to make
                an impact.
              </p>
              <p>
                With an instinct for turning challenges into opportunities, he’s
                not just building applications—he’s shaping the future of
                digital experiences. As the founder of AFNANCODER, Afnan blends
                expertise in full-stack development with a visionary approach to
                business, where every project is an exploration of what can be
                achieved when creativity and technology unite.
              </p>
              {/* <p>
                For Afnan, technology isn’t just about solving problems; it’s
                about transforming them into something more meaningful. It’s the
                thrill of discovery, the quest for innovation, and the belief
                that every line of code holds the potential to change the world.
              </p> */}
            </div>
            <div className={styles.CV}>
              <a href='/muhammad afnan.pdf' download>
                <button>DOWNLOAD CV</button>
              </a>
            </div>
          </div>
        </div>
      </div>
      <hr className={styles.lineColor} />
    </>
  )
}

export default About
