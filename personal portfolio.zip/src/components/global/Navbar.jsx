import React from 'react';
import styles from '../styles/global/Navbar.module.css';

const Navbar = () => {
  const handleHireMeClick = () => {
    
    const whatsappNumber = '923144087039';
    const message = 'Hello Muhammad Afnan, I am interested in hiring you.';

    
    const whatsappURL = `https://wa.me/${whatsappNumber}?text=${encodeURIComponent(message)}`;

    
    window.open(whatsappURL, '_blank'); 
  };

  return (
    <>
      <div className={styles.navbarContainer}>
        <div className={styles.logo}>
          {/* <h1>Muhammad Afnan</h1> */}
          <img src="/images/logo6.jpg" alt="" />
        </div>
        <div className={styles.navbarPages}>
          <div className={styles.navPages}>
            {/* <a href="#hero">HOME</a> */}
            <a href="#about">ABOUT</a>
            <a href="#skills">SKILLS</a>
            <a href="#services">SERVICES</a>
            <a href="#portfolio">PORTFOLIO</a>
            <a href="#connect">CONTACT</a>
          </div>
          <div className={styles.hireMe}>
            <button onClick={handleHireMeClick}>HIRE ME</button>
          </div>
        </div>
      </div>
    </>
  );
};

export default Navbar;
